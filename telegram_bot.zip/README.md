# Telegram Smart Bot
بوت تجريبي باستخدام python-telegram-bot.
